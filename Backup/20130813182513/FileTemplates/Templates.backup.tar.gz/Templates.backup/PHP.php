<?php

class ${1:$name} ${2:extends ${3:SomeClass}} {
	
	function __construct(){
		$0
	}
}

?>